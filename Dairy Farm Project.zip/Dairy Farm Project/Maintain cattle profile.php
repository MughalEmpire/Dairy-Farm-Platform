<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myfarm";
$link = mysqli_connect($servername, $username, $password, $dbname);
$con = mysqli_select_db($link, $dbname);
if ($con) {
    echo ("connection ok");
} else {
    die("connection failed because" . mysqli_connect_error());
}
?>


<!DOCTYPE html>
<html>

<head>
    <title>Create and Maintain Cattle Profile</title>
    <style>
        .container {
            background-color: #f2f2f2;
            padding: 20px;
            border-radius: 10px;
        }

        .container label {
            margin-right: 10px;
            background-repeat: no-repeat;
        }

        .container .row {
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 10px;
            width: 550px;
            position: relative;
            left: 560px;
            /* border: 2px solid black; */
            border-radius: 4px;
            height: 30px;
        }

        .container .row input {
            flex: 1;
            margin-left: 10px;
        }

        #insert-btn {
            color: white;
            background-color: rgb(55, 204, 55);
            width: 250px;
            height: 30px;
            border: 2px solid rgb(55, 204, 55);
            border-radius: 5px;
            font-size: 20px;
            /* position: relative; */
            /* left: 650px; */

        }

        #insert-btn:hover {
            color: white;
            background-color: darkgreen;
            cursor: pointer;
        }

        #update-btn {
            color: white;
            background-color: rgb(55, 204, 55);
            width: 250px;
            height: 30px;
            border: 2px solid rgb(55, 204, 55);
            border-radius: 5px;
            font-size: 20px;
        }

        #update-btn:hover {
            color: white;
            background-color: darkgreen;
            cursor: pointer;
        }

        #delete-btn {
            color: white;
            background-color: rgb(55, 204, 55);
            width: 250px;
            height: 30px;
            border: 2px solid lightgreen;
            border-radius: 5px;
            font-size: 20px;
        }

        #delete-btn:hover {
            color: white;
            background-color: darkgreen;
            cursor: pointer;
        }

        .container .head {
            text-align: center;
        }


        
    </style>
</head>

<body>
    <form name="form1" , action="" , method="post">
        <center>
            <h1 class="headig">Maintain Cattle Profile</h1>
        </center>
        <div class="container">

            <center>
                <h1 class="head">Insert Cattle Data</h1>
            </center>
            <div class="row">
                <label for="cow-id-1">Cow ID:</label><br>
                <input type="number" name="cowid" id="cow-id-1"> <br>
                <label for="cow-color-1">Color:</label>
                <input type="text" name="cowcolor" id="cow-color-1">
            </div>

            <div class="row">
                <label for="cow-species-1">Species:</label>
                <input type="text" name="cowspecies" id="cow-species-1">
                <label for="cow-breed-1">Breed:</label>
                <input type="text" name="breed" id="cow-breed-1">
            </div>

            <div class="row">
                <label for="cow-temperature-1">Temperature:</label>
                <input type="number" name="temperature" id="cow-temperature-1">
                <label for="cow-price-1">Price:</label>
                <input type="number" name="price" id="cow-price-1">
            </div>
            <br><br>
            <center><button input type="submit" name="submit1" value="insert" id="insert-btn">Insert</button></center>
            <br>
            <center><button input type="submit" name="submit2" value="display" id="insert-btn">Display</button></center>
            <br><br>







            <?php
            if (isset($_POST["submit1"])) {
                $query="insert into insertion values (" . $_POST["cowid"] . ",'" . $_POST["cowcolor"] . "','" . $_POST["cowspecies"] . "', '" . $_POST["breed"] . "'," . $_POST["temperature"] . "," . $_POST["price"] . ")";
                
               //echo $query; 
                mysqli_query($link,$query);
                
                
            
                echo "Record inserted successfully!";
            }

            if (isset($_POST["submit2"])) {
                $res = mysqli_query($link, "select * from insertion");
                echo "<center>";
                echo "<table border = 1>";
                echo "<tr>";
                echo "<th>";
                echo "cowid";
                echo "</th>";
                echo "<th>";
                echo "cowcolor";
                echo "</th>";
                echo "<th>";
                echo "cowspecies";
                echo "</th>";
                echo "<th>";
                echo "breed";
                echo "</th>";
                echo "<th>";
                echo "temperature";
                echo "</th>";
                echo "<th>";
                echo "price";
                echo "</th>";

                while ($row = mysqli_fetch_array($res)) {
                    echo "<tr>";
                    echo "<td>";
                    echo $row["cowid"];
                    echo "</td>";
                    echo "<td>";
                    echo $row["cowcolor"];
                    echo "</td>";
                    echo "<td>";
                    echo $row["cowspecies"];
                    echo "</td>";
                    echo "<td>";
                    echo $row["breed"];
                    echo "</td>";
                    echo "<td>";
                    echo $row["temperature"];
                    echo "</td>";
                    echo "<td>";
                    echo $row["price"];
                    echo "</td>";
                }

                echo "</table>";
                echo "</center>";
            }
            ?>

            <div class="container">
                <center>
                    <h1 class="head">Update Cattle Data</h1>
                </center>
                <div class="row">
                    <label for="cow-id-1_up">Cow ID:</label>
                    <input type="number" name="cowidup" id="cow-id-1">
                    <label for="cow-color-1">Color:</label>
                    <input type="text" name="cowcolorup" id="cow-color-1">
                </div>

                <div class="row">
                    <label for="cow-species-1">Species:</label>
                    <input type="text" name="cowspeciesup" id="cow-species-1">
                    <label for="cow-breed-1">Breed:</label>
                    <input type="text" name="breedup" id="cow-breed-1">
                </div>

                <div class="row">
                    <label for="cow-temperature-1">Temperature:</label>
                    <input type="text" name="temperatureup" id="cow-temperature-1">
                    <label for="cow-price-1">Price:</label>
                    <input type="text" name="priceup" id="cow-price-1">
                </div>
                <br><br>

                <center><button input type="submit" name="submit3" value="update" id="update-btn">Update</button></center>
                <br>
                <center><button input type="submit" name="submit4" value="display" id="update-btn">Display</button></center>
                <br><br>


 <?php
 
 if(isset($_POST['submit3'])){
    echo "Processing updation"."<br>";
    $query="UPDATE insertion SET ";
    $id_there=false;
    $first_time=true;
    
    if(!empty($_POST['cowidup'])){
        $id_there=true;
    }

    if($id_there){

    if(!empty($_POST['cowspeciesup'])){
        $first_time=false;
        $query.=" cowspecies = '".$_POST['cowspeciesup']."'";
    }

    if(!empty($_POST['cowcolorup'])){
        if(!$first_time){
            $query.=",";
        }
        $first_time=false;

        $query.=" cowcolor='".$_POST['cowcolorup']."'";
    }

    if(!empty($_POST['breedup'])){
        if(!$first_time){
            $query.=",";
        }
        $first_time=false;
        $query.=" breed = '".$_POST['breedup']."'";
    }

    if(!empty($_POST['tmperatureup'])){
        if(!$first_time){
            $query.=",";
        }
        $first_time=false;
        $query.=" temperature = ".$_POST['temperatureup'];
    }

    if(!empty($_POST['priceup'])){
        if(!$first_time){
            $query.=",";
        }
        $first_time=false;
        $query.=" price = ".$_POST['priceup'];
    }

    if($first_time){
        echo "PLEASE PROVIDE SOME VALUES FIRST<br>";
    }else{
        $query.=" where cowid=".$_POST['cowidup'];
        mysqli_query($link,$query);
    }
    }else{
        echo "Please provide id";
    }
 }

 if(isset($_POST["submit4"])) {
    $res = mysqli_query($link, "select * from insertion");
    echo"<center>"; 
    echo"<table border = 1>";
    echo"<tr>";
    echo "<th>"; echo "cowid"; echo"</th>";
    echo "<th>"; echo "cowcolor"; echo"</th>";
    echo "<th>"; echo "cowspecies"; echo"</th>";
    echo "<th>"; echo "breed"; echo"</th>";
    echo "<th>"; echo "temperature"; echo"</th>";
    echo "<th>"; echo "price"; echo"</th>";

    while($row=mysqli_fetch_array($res))
    {
        echo"<tr>";
        echo"<td>"; echo $row["cowid"]; echo"</td>";
        echo"<td>"; echo $row["cowcolor"]; echo"</td>";
        echo"<td>"; echo $row["cowspecies"]; echo"</td>";
        echo"<td>"; echo $row["breed"]; echo"</td>";
        echo"<td>"; echo $row["temperature"]; echo"</td>";
        echo"<td>"; echo $row["price"]; echo"</td>";

    }

    echo"</table>";
    echo"</center>";

}
?>  







                <div class="container">
                    <center>
                        <h1 class="head">Delete Cattle Data</h1>
                    </center>
                    <div class="row">
                        <label for="cow-id-1">Cow ID:</label>
                        <input type="number" name="cowid_del" id="cow-id-1">
                    </div>
                    <br>
                    <center><button input type="submit" name="submit5" value="delete-btn" id="delete-btn">Delete</button></center>
                    <br>
                    <center><button input type="submit" name="submit6" value="display" id="delete-btn">Display</button></center>
                    <br><br>
                </div>
            </div>

            <?php
            if (isset($_POST["submit5"])) {
                $qqq="Delete from insertion WHERE cowid=".$_POST['cowid_del'];
                echo $qqq;
                if (mysqli_query($link, $qqq))
                    echo "Record deleted successfully!";
                else
                    echo "Record Does not exist";
            }
            if(isset($_POST["submit6"])) {
                $res = mysqli_query($link, "select * from insertion");
                echo"<center>"; 
                echo"<table border = 1>";
                echo"<tr>";
                echo "<th>"; echo "cowid"; echo"</th>";
                echo "<th>"; echo "cowcolor"; echo"</th>";
                echo "<th>"; echo "cowspecies"; echo"</th>";
                echo "<th>"; echo "breed"; echo"</th>";
                echo "<th>"; echo "temperature"; echo"</th>";
                echo "<th>"; echo "price"; echo"</th>";
            
                while($row=mysqli_fetch_array($res))
                {
                    echo"<tr>";
                    echo"<td>"; echo $row["cowid"]; echo"</td>";
                    echo"<td>"; echo $row["cowcolor"]; echo"</td>";
                    echo"<td>"; echo $row["cowspecies"]; echo"</td>";
                    echo"<td>"; echo $row["breed"]; echo"</td>";
                    echo"<td>"; echo $row["temperature"]; echo"</td>";
                    echo"<td>"; echo $row["price"]; echo"</td>";
            
                }
            
                echo"</table>";
                echo"</center>";
            
            }

            ?>

</body>
</form>

</html>







<!-- <script>
    // Insert button functionality
    document.getElementById("insert-btn").addEventListener("click", function() {
      // Get values from input fields
      var cowId = document.getElementById("cow-id-1").value;
      var cowColor = document.getElementById("cow-color-1").value;
      var cowSpecies = document.getElementById("cow-species-1").value;
      var cowBreed = document.getElementById("cow-breed-1").value;
      var cowTemperature = document.getElementById("cow-temperature-1").value;
      var cowPrice = document.getElementById("cow-price-1").value;

      // Perform insert operation with the values
      
      // Clear input fields
      document.getElementById("cow-id-1").value = "";
      document.getElementById("cow-color-1").value = "";
      document.getElementById("cow-species-1").value = "";
      document.getElementById("cow-breed-1").value = "";
      document.getElementById("cow-temperature-1").value = "";
      document.getElementById("cow-price-1").value = "";
    });



    // Update button functionality
    document.getElementById("update-btn").addEventListener("click", function() {
      // Get values from input fields
      var cowId = document.getElementById("cow-id-1").value;
      var cowColor = document.getElementById("cow-color-1").value;
      var cowSpecies = document.getElementById("cow-species-1").value;
      var cowBreed = document.getElementById("cow-breed-1").value;
      var cowTemperature = document.getElementById("cow-temperature-1").value;
      var cowPrice = document.getElementById("cow-price-1").value;

      // Perform update operation with the values
      
      // Clear input fields
      document.getElementById("cow-id-1").value = "";
      document.getElementById("cow-color-1").value = "";
      document.getElementById("cow-species-1").value = "";
      document.getElementById("cow-breed-1").value = "";
      document.getElementById("cow-temperature-1").value = "";
      document.getElementById("cow-price-1").value = "";
    });


     // Delete button functionality
     document.getElementById("delete-btn").addEventListener("click", function() {
      // Get the cow ID to be deleted
      var cowId = document.getElementById("cow-id-1").value;

      // Perform delete operation with the cow ID
      
      // Clear the input field
      document.getElementById("cow-id-1").value = "";
    });

  </script> -->