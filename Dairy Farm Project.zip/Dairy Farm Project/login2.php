<!DOCTYPE html>
<html>

<head>
    <title>Login Page</title>
    <style>
        body {
            background-image: url("login image.jpg");
            background-size: cover;
            background-position: center;
            font-family: Arial, sans-serif;
        }

        .container {
            width: 400px;
            margin: 150px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input[type="text"],
        .form-group input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        .form-group .show-password {
            margin-top: 5px;
        }

        .form-group .show-password input[type="checkbox"] {
            margin-right: 5px;
        }

        .form-group button {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        .register-link {
            text-align: center;
            margin-top: 10px;
        }

        .btn input[type="submit"] {
            color: white;
            background-color: rgb(47, 194, 47);
            width: 150px;
            height: 25px;
            border: 2px solid lightgreen;
            border-radius: 8px;
            font-size: 18px;
        }

        .btn input[type="submit"]:hover {
            color: white;
            background-color: darkgreen;
            cursor: pointer;
        }
    </style>
    <script>
        function togglePassword() {
            var passwordInput = document.getElementById("password");
            var showPasswordCheckbox = document.getElementById("showPassword");

            if (showPasswordCheckbox.checked) {
                passwordInput.type = "text";
            } else {
                passwordInput.type = "password";
            }
        }
    </script>
</head>

<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Myfarm";
// Create connection
$conn = mysqli_connect($servername, $username, $password, "myfarm");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";

$error = "";
	$username = "";
	if (isset($_REQUEST["btnSubmit"])) {

		$username = $_REQUEST["username"];
		$password = $_REQUEST["password"];

		$sql = "SELECT * FROM login where username='".$username."' and password=".$password;

        //echo $sql;
		$result = mysqli_query($conn, $sql);

		$recordsFound = mysqli_num_rows($result);

		if ($recordsFound > 0) {
			$row = mysqli_fetch_assoc($result);
			$_SESSION['username'] = $username;
			$_SESSION["password"] = $row["password"];
			header('Location: Dashboard.html');
		} else {
			$_SESSION["user"] = null;
			$error = "Invalid credentials !";
		}

	}
// if (isset($_REQUEST["btnRegister"]) == true) {
//     header('Location: register.php');
// }

$conn->close();

// // Assuming you have already retrieved the username and password from the login form
// $username = $_POST['admin'];
// $password = $_POST['123'];

// // Connect to the database
// $mysqli = new mysqli('127.0.0.1', 'root', '', 'login-database');

// // Check connection
// if ($mysqli->connect_error) {
//     die('Connection failed: ' . $mysqli->connect_error);
// }

// // Prepare and execute the insert query
// $stmt = $mysqli->prepare("INSERT INTO logintable (username, password) VALUES (admin, 123)");
// $stmt->bind_param("ss", $admin, 123);
// $stmt->execute();

// // Check if the login is successful
// if ($stmt->affected_rows > 0) {
//     // Credentials are valid, redirect to dashboard.html
//     header("Location: dashboard.html");
//     exit();
// } else {
//     // Credentials are invalid, display an error message or perform any other necessary action
//     echo "Invalid username or password";
// }

// // Close the statement and database connection
// $stmt->close();
// $mysqli->close();
?>


<body>
    <div class="container">
        <center>
            <h2>Login</h2>
        </center>
        <form action="login2.php" method="POST">
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" id="username" name="username">
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password">
            <div class="show-password">
                <input type="checkbox" id="showPassword" onclick="togglePassword()">
                <label for="showPassword">Show Password</label>
            </div>
        </div>

        <!-- <div class="btn">
            <center><input type="submit" name="btnSubmit" value="login">Login</center>
        </div> -->
        <div class="btn">
            <center><input type="submit" name="btnSubmit" value="Login"></center>
        </div>

        <span><?php echo $error ?></span>

        <!-- <center><input type="submit"  value="login" id="login-btn"></center> -->
        </form>
        <div class="register-link">
            <a href="register.html">Register</a> | <a href="forgot-password.html">Forgot Password?</a>
        </div>
    </div>
</body>

</html>